<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
       <p>This is my home page</p>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
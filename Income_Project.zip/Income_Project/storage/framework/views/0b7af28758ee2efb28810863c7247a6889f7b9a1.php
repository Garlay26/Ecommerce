<?php $__env->startSection('title','Log In'); ?>
<?php $__env->startSection('content'); ?>
    <p class="para">This is Log in Page</p>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Shop'); ?>
<?php $__env->startSection('content'); ?>
    This is shop page

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
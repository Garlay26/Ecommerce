@extends('layout.master')
@section('title','Log In')
@section('content')
    <p class="para">This is Log in Page</p>
    @endsection
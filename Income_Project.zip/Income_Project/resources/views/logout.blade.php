@extends ('layout.master')
@section('title','Log Out')
@section('content')
<p>This is Log Out Page</p>
    @endsection
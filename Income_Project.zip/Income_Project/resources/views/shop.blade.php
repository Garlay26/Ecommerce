@extends ('layout.master')
@section ('title', 'Shop')
@section('content')
    This is shop page

    @endsection
@extends ("layout.master")

@section('title', 'Home')
@section('content')
       <p>This is my home page</p>
    @endsection
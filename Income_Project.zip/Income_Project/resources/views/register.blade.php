@extends ('layout.master')
@section('title', 'Register')
@section('content')
        <p>This is Register Page</p>
    @endsection
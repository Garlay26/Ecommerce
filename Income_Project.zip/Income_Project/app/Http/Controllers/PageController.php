<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    function login(){
        return view('login');

    }

    function  home(){
        return view('home');
    }

    function shop(){
        return view('shop');
    }

    function login_page(){
        return view('login');
    }

    function logout_page(){
        return view('logout');
    }

    function register(){
        return view('register');
    }
}


